//task1
document.getElementById('second').addEventListener("click", function () {
    let csecond = document.getElementById('second')
    let cfifth = document.getElementById('fifth')

    swap(second, fifth);
})

document.getElementById('fifth').addEventListener("click", function () {
    let csecond = document.getElementById('second')
    let cfifth = document.getElementById('fifth')

    swap(second, fifth)
})

function swap(csec, cfif) {
    let temp = csec.innerHTML
    csec.innerHTML = cfif.innerHTML
    cfif.innerHTML = temp
}

//task2
let R = 3;
let square = 5/2*(R)^2*Math.sin(72);
document.getElementById("square").innerHTML = "Penta square: "+ square;

//task3


function reversClick()
{
    let num = document.getElementById("reverseInput").value;
    let num1 = num; 
    num1 = num.split("").reverse().join("");
    let res = num + " ---> " + num1;
    document.cookie = "reversed="+num;
    alert(res);
    {
        alert(document.cookie);
    }
} 
function showCookie() {
  let lastResult = getCookie('reversed');
  console.log('lastResult ---' + lastResult);
  lastResult = lastResult !== "" ? lastResult : "Nothing";
  
  if (lastResult !== "Nothing") {
      alert("Reversed: " + lastResult + "\nAfter pressing OK it will be deleted");
      location.reload;
  }

  console.log(document.cookie);
  console.log(lastResult);

  document.cookie = "reversed=";
  document.getElementById('reverseInput').style.visibility = 'visible';
}

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) === 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
    


//task4
function saveAndChangeColor() {
  let color = document.getElementById("inputColor").value;

  document.getElementById('first').style.borderColor = color;
  

  document.getElementById('second').style.borderColor = color;
  

  document.getElementById('third').style.borderColor = color;
  

  document.getElementById('fourth').style.borderColor = color;
  

  document.getElementById('fifth').style.borderColor = color;
  

  document.getElementById('sixth').style.borderColor = color;
  

  document.getElementById('seventh').style.borderColor = color;

  console.log(color);

  localStorage.setItem('color', color);

  changeColor();
}

function changeColor() {
  let color = localStorage.getItem('color');

  if (color === '') {
    return;
  }

  console.log('color of borders at storage ---' + color);

  if (color === null || color === undefined) {
    return;
  }
  
}